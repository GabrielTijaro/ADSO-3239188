class Client {
  constructor(id, type_document, document, name, address, phone, email) {
    this.id = id;
    this.type_document = type_document;
    this.document = document;
    this.name = name;
    this.address = address;
    this.phone = phone;
    this.email = email;
  }
}
