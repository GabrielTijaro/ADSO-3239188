// Business logic for reservations.
const ReservationController = {
  key: "reservations",

  getAll() {
    return JSON.parse(localStorage.getItem(this.key)) || [];
  },

  saveAll(list) {
    localStorage.setItem(this.key, JSON.stringify(list));
  },

  validate(data) {
    if (!data.name) return "Name is required";
    if (!data.client_id) return "Select a client";
    if (!ClientController.getById(data.client_id)) return "The client does not exist";
    return null;
  },

  create(data) {
    const error = this.validate(data);
    if (error) return { ok: false, message: error };

    const list = this.getAll();
    const id = list.length ? Math.max(...list.map((r) => r.id)) + 1 : 1;
    list.push(new Reservation(id, data.name, data.description, data.client_id));
    this.saveAll(list);
    return { ok: true, message: "Reservation created" };
  },

  update(id, data) {
    const error = this.validate(data);
    if (error) return { ok: false, message: error };

    const list = this.getAll();
    const index = list.findIndex((r) => r.id === id);
    list[index] = new Reservation(id, data.name, data.description, data.client_id);
    this.saveAll(list);
    return { ok: true, message: "Reservation updated" };
  },

  delete(id) {
    this.saveAll(this.getAll().filter((r) => r.id !== id));
    return { ok: true, message: "Reservation deleted" };
  },
};
