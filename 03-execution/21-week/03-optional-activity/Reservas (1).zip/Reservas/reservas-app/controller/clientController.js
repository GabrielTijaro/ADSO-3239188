// Business logic for clients. localStorage works as our simple "database".
const ClientController = {
  key: "clients",

  getAll() {
    return JSON.parse(localStorage.getItem(this.key)) || [];
  },

  saveAll(list) {
    localStorage.setItem(this.key, JSON.stringify(list));
  },

  getById(id) {
    return this.getAll().find((c) => c.id === id);
  },

  validate(data, list, currentId) {
    if (!data.document || !data.name) {
      return "Document and name are required";
    }
    if (list.some((c) => c.document === data.document && c.id !== currentId)) {
      return "A client with this document already exists";
    }
    return null;
  },

  create(data) {
    const list = this.getAll();
    const error = this.validate(data, list, null);
    if (error) return { ok: false, message: error };

    const id = list.length ? Math.max(...list.map((c) => c.id)) + 1 : 1;
    list.push(
      new Client(id, data.type_document, data.document, data.name, data.address, data.phone, data.email)
    );
    this.saveAll(list);
    return { ok: true, message: "Client created" };
  },

  update(id, data) {
    const list = this.getAll();
    const error = this.validate(data, list, id);
    if (error) return { ok: false, message: error };

    const index = list.findIndex((c) => c.id === id);
    list[index] = new Client(id, data.type_document, data.document, data.name, data.address, data.phone, data.email);
    this.saveAll(list);
    return { ok: true, message: "Client updated" };
  },

  delete(id) {
    if (ReservationController.getAll().some((r) => r.client_id === id)) {
      return { ok: false, message: "Cannot delete: the client has reservations" };
    }
    this.saveAll(this.getAll().filter((c) => c.id !== id));
    return { ok: true, message: "Client deleted" };
  },
};
